from PIL import Image
import subprocess
import util
import errors
import sys
"""

Image_reader by Ahmed ezzat
at : fb.com/ahmed.ezzat110
feel free to ask anything :D


"""
tesseract_exe_name = 'tesseract'
scratch_image_name = "temp.bmp"
scratch_text_name_root = "temp"
cleanup_scratch_flag = True
def call_tesseract(input_filename, output_filename):
	args = [tesseract_exe_name, input_filename, output_filename]
	proc = subprocess.Popen(args)
	retcode = proc.wait()
	if retcode!=0:
		errors.check_for_errors()
def image_to_string(im, cleanup = cleanup_scratch_flag):
	try:
		util.image_to_scratch(im, scratch_image_name)
		call_tesseract(scratch_image_name, scratch_text_name_root)
		text = util.retrieve_text(scratch_text_name_root)
	finally:
		if cleanup:
			util.perform_cleanup(scratch_image_name, scratch_text_name_root)
	return text
def image_file_to_string(filename, cleanup = cleanup_scratch_flag, graceful_errors=True):
	try:
		try:
			call_tesseract(filename, scratch_text_name_root)
			text = util.retrieve_text(scratch_text_name_root)
		except errors.Tesser_General_Exception:
			if graceful_errors:
				im = Image.open(filename)
				text = image_to_string(im, cleanup)
			else:
				raise
	finally:
		if cleanup:
			util.perform_cleanup(scratch_image_name, scratch_text_name_root)
	return text
	


im = Image.open(sys.argv[1])
text = image_to_string(im)
print text
